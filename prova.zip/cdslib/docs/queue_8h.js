var queue_8h =
[
    [ "QUEUE", "queue_8h.html#a4003941f54b36b2c4308e07fd32e71d5", null ],
    [ "queueAdd", "queue_8h.html#aa75db2b9ff343b2ffb4f586860ee6087", null ],
    [ "queueCapacity", "queue_8h.html#a4bf9c7193c9fa1502ce4574a8169b5b3", null ],
    [ "queueClear", "queue_8h.html#a2fd952b11e18520e216e41d9460ba52f", null ],
    [ "queueCreate", "queue_8h.html#aa269c653bad67d1b1ee12704d9ae4ac3", null ],
    [ "queueFree", "queue_8h.html#aec6a094521e89fe346465578137f39a4", null ],
    [ "queuePeek", "queue_8h.html#ac507adc3c0fc13851104f0412f81c26f", null ],
    [ "queueRemove", "queue_8h.html#a14964ca34a052e631dd3340cddfbe5bd", null ],
    [ "queueSize", "queue_8h.html#a07f0794b21b29b8f0a82d2a2f33563bd", null ]
];