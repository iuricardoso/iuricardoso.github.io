var files_dup =
[
    [ "list.h", "list_8h.html", "list_8h" ],
    [ "mainpage.doxygen", "mainpage_8doxygen.html", null ],
    [ "queue.h", "queue_8h.html", "queue_8h" ],
    [ "stack.h", "stack_8h.html", "stack_8h" ]
];