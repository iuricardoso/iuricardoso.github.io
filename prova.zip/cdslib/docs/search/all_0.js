var searchData=
[
  ['exemplo_20de_20uso_20de_20lista',['Exemplo de uso de Lista',['../example_list.html',1,'']]],
  ['exemplo_20de_20uso_20de_20fila_2e',['Exemplo de uso de Fila.',['../example_queue.html',1,'']]],
  ['exemplo_20de_20uso_20de_20pilha',['Exemplo de uso de Pilha',['../example_stack.html',1,'']]]
];
