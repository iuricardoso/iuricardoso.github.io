var searchData=
[
  ['begin',['begin',['../struct_queue.html#a9320720f4d683cc7c76f800be700ac35',1,'Queue']]]
];
