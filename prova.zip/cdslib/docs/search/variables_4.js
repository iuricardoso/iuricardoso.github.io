var searchData=
[
  ['limit',['limit',['../struct_list.html#abccf68b7cb494f01c3b32705841ec989',1,'List::limit()'],['../struct_stack.html#a093d9695bc7f56e2e457d8ccf15652c1',1,'Stack::limit()']]]
];
