var searchData=
[
  ['list_5fis_5fempty',['LIST_IS_EMPTY',['../list_8h.html#a8c4c01cac35e54e00185c8c6ff6b0347',1,'list.h']]],
  ['list_5fis_5ffull',['LIST_IS_FULL',['../list_8h.html#a14f6db9297a5ed3dbac62317ed15db15',1,'list.h']]]
];
