var searchData=
[
  ['stack',['STACK',['../stack_8h.html#adbe792eb291011db4e579c0c3888b70c',1,'stack.h']]]
];
