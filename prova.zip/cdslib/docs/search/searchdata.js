var indexSectionsWithContent =
{
  0: "eilmnpqs",
  1: "lmqs",
  2: "lqs",
  3: "lqs",
  4: "iln",
  5: "ep"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Ficheiros",
  2: "Funções",
  3: "Definições de tipos",
  4: "Macros",
  5: "Páginas"
};

