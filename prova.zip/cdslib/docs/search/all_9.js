var searchData=
[
  ['v',['v',['../struct_queue.html#a67806b49e20fb1170422969965db6ecb',1,'Queue::v()'],['../struct_stack.html#a67806b49e20fb1170422969965db6ecb',1,'Stack::v()']]]
];
