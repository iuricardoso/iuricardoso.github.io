var struct_stack =
[
    [ "elementSize", "struct_stack.html#af884332e6713af9425451adde09e0024", null ],
    [ "limit", "struct_stack.html#a093d9695bc7f56e2e457d8ccf15652c1", null ],
    [ "size", "struct_stack.html#a439227feff9d7f55384e8780cfc2eb82", null ],
    [ "v", "struct_stack.html#a67806b49e20fb1170422969965db6ecb", null ]
];