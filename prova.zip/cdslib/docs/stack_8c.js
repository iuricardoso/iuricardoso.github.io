var stack_8c =
[
    [ "Stack", "struct_stack.html", "struct_stack" ],
    [ "stackClear", "stack_8c.html#a74731a4f6cb3fca8d975f5ab36a27a82", null ],
    [ "stackCreate", "stack_8c.html#ad1d1d1e42f1f6a41fcf2b1a4b66d2a9f", null ],
    [ "stackFree", "stack_8c.html#ae47ded03b0f8e495c5644eec355d6fb4", null ],
    [ "stackLimit", "stack_8c.html#add6b50cc331f38f05333b977d8202cca", null ],
    [ "stackPeekTop", "stack_8c.html#a4227f617da01613e52bba4b597023ecb", null ],
    [ "stackPop", "stack_8c.html#a8d290db4958035e3d62fbf5c601a9af6", null ],
    [ "stackPush", "stack_8c.html#a99dd2af7068b686298a5d1033a4af570", null ],
    [ "stackSize", "stack_8c.html#af4afc5a0e35c9b973786473c3a066b54", null ]
];