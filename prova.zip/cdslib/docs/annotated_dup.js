var annotated_dup =
[
    [ "List", "struct_list.html", "struct_list" ],
    [ "Queue", "struct_queue.html", "struct_queue" ],
    [ "Stack", "struct_stack.html", "struct_stack" ]
];