var struct_list =
[
    [ "data", "struct_list.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "elementSize", "struct_list.html#af884332e6713af9425451adde09e0024", null ],
    [ "limit", "struct_list.html#abccf68b7cb494f01c3b32705841ec989", null ],
    [ "size", "struct_list.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];