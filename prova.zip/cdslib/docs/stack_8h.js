var stack_8h =
[
    [ "STACK", "stack_8h.html#adbe792eb291011db4e579c0c3888b70c", null ],
    [ "stackCapacity", "stack_8h.html#affe35690517d511778fbc824a63a175c", null ],
    [ "stackClear", "stack_8h.html#a74731a4f6cb3fca8d975f5ab36a27a82", null ],
    [ "stackCreate", "stack_8h.html#a93da551c0a486692b2aa2ffc75bb5f24", null ],
    [ "stackFree", "stack_8h.html#ae47ded03b0f8e495c5644eec355d6fb4", null ],
    [ "stackPeekTop", "stack_8h.html#a4227f617da01613e52bba4b597023ecb", null ],
    [ "stackPop", "stack_8h.html#a8d290db4958035e3d62fbf5c601a9af6", null ],
    [ "stackPush", "stack_8h.html#a99dd2af7068b686298a5d1033a4af570", null ],
    [ "stackSize", "stack_8h.html#af4afc5a0e35c9b973786473c3a066b54", null ]
];