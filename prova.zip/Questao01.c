/** Quest�o 01.c: Implemente a fun��o quick_sort(). Ela recebe por par�metro um
    vetor de float, o �ndice do limite esquerdo e do limite direito.
    Deve ordenar o vetor de forma crescente utilizando o m�todo de
    ordena��o r�pida (quick sort).
*/

#include <stdio.h> // printf(), scanf()
#include <stdlib.h> //srand(), rand(), NULL, qsort()
#include <time.h> // time()

int compara(const void * a, const void * b);
void quick_sort(float vetor[], int esq, int dir);

int main() {
    srand(time(NULL));
    const int tam = 10;
    float vetor[tam];
    float vetor2[tam];

    int i;
    printf("Vetor nao ordenado        : ");
    for (i=0; i<tam; i++) {
        vetor[i] = (float)(rand() % 1000) / 10.0;
        vetor2[i] = vetor[i]; // cria uma c�pia
        printf("%0.1f ", vetor[i]);
    }
    printf("\n\n");

    // ordena o vetor.
    quick_sort(vetor, 0, tam-1);

    printf("Vetor ordenado (crescente): ");
    for (i=0; i<tam; i++) {
        printf("%0.1f ", vetor[i]);
    }
    printf("\n");

    // daqui para baixo, � apenas para verificar
    // se sua ordena��o funcionou corretamenta.
    qsort(vetor2, tam, sizeof(float), compara);

    int erros = 0;
    printf("Gabarito                  : ");
    for (i=0; i<tam; i++) {
        printf("%0.1f ", vetor2[i]);
        if (vetor[i] != vetor2[i]) {
            erros++;
        }
    }
    printf("\n\n");

    if (erros == 0) {
        printf("CORRETO!\n");
    }
    else {
        float perc = (float)erros / (float)tam * 100.0;
        printf("INCORRETO! Numero de erros: %d/%d (%5.2f%%)\n", erros, tam, perc);
    }

    return 0;
}


void quick_sort(float vetor[], int esq, int dir) {
    // IMPLEMENTE ESTA FUN��O ------------------------------
    //
    // Ordenar vetor pelo m�todo de ordena��o r�pida.
    //
    // -----------------------------------------------------
}


int compara(const void * a, const void * b) {
    float dif = *(float *)a - *(float *)b;

    if (dif > 0) {
            return 1;
    }

    if (dif < 0) {
            return -1;
    }

    return 0;
}
